package com.company.servlet;

import com.company.dao.User;

public class UserDao {

	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

}
